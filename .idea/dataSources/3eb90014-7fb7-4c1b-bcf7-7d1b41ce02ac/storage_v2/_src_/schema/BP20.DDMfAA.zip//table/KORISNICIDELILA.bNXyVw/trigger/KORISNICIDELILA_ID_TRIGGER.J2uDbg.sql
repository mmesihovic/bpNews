create trigger KORISNICIDELILA_ID_TRIGGER
  before insert
  on KORISNICIDELILA
  for each row
  BEGIN
  SELECT KorisniciDelila_ID_Seq.NEXTVAL
  INTO   :new.ID
  FROM   dual;
END;
/

