create trigger KORISNICISANJA_ID_TRIGGER
  before insert
  on KORISNICISANJA
  for each row
  BEGIN
  SELECT KorisniciSanja_ID_Seq.NEXTVAL
  INTO   :new.ID
  FROM   dual;
END;
/

