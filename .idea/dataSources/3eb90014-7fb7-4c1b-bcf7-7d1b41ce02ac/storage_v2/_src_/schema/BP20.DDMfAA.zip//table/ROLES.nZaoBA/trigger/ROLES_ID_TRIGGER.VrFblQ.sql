create trigger ROLES_ID_TRIGGER
  before insert
  on ROLES
  for each row
  BEGIN
  SELECT Roles_ID_Seq.NEXTVAL
  INTO   :new.ID
  FROM   dual;
END;
/

