create trigger TAGS_ID_TRIGGER
  before insert
  on TAGS
  for each row
  BEGIN
  SELECT Tags_ID_Seq.NEXTVAL
  INTO   :new.ID
  FROM   dual;
END;
/

