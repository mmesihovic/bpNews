create trigger COMMENTS_ID_TRIGGER
  before insert
  on COMMENTS
  for each row
  BEGIN
  SELECT Comments_ID_Seq.NEXTVAL
  INTO   :new.ID
  FROM   dual;
END;
/

