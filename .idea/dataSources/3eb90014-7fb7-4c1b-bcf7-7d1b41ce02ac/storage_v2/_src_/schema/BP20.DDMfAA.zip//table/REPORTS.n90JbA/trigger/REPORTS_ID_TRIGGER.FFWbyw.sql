create trigger REPORTS_ID_TRIGGER
  before insert
  on REPORTS
  for each row
  BEGIN
  SELECT Reports_ID_Seq.NEXTVAL
  INTO   :new.ID
  FROM   dual;
END;
/

