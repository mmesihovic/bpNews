create trigger FAJLOVISANJA_ID_TRIGGER
  before insert
  on FAJLOVISANJA
  for each row
  BEGIN
  SELECT FajloviSanja_ID_Seq.NEXTVAL
  INTO   :new.ID
  FROM   dual;
END;
/

