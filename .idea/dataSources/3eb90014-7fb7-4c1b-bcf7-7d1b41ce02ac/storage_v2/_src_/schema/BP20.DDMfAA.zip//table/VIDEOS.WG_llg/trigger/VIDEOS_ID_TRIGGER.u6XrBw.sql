create trigger VIDEOS_ID_TRIGGER
  before insert
  on VIDEOS
  for each row
  BEGIN
  SELECT Videos_ID_Seq.NEXTVAL
  INTO   :new.ID
  FROM   dual;
END;
/

