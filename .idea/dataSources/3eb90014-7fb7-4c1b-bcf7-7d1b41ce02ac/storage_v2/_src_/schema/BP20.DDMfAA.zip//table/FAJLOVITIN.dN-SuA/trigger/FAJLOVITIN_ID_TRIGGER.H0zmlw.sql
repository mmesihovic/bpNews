create trigger FAJLOVITIN_ID_TRIGGER
  before insert
  on FAJLOVITIN
  for each row
  BEGIN
  SELECT FajloviTin_ID_Seq.NEXTVAL
  INTO   :new.ID
  FROM   dual;
END;
/

