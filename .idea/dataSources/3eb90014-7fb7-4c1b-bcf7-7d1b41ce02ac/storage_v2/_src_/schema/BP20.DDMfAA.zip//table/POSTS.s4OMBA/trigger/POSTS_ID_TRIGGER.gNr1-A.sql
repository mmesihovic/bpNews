create trigger POSTS_ID_TRIGGER
  before insert
  on POSTS
  for each row
  BEGIN
  SELECT Posts_ID_Seq.NEXTVAL
  INTO   :new.ID
  FROM   dual;
END;
/

