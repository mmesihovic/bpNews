create trigger KORISNICITIN_ID_TRIGGER
  before insert
  on KORISNICITIN
  for each row
  BEGIN
  SELECT KorisniciTin_ID_Seq.NEXTVAL
  INTO   :new.ID
  FROM   dual;
END;
/

