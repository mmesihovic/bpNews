create trigger USERS_ID_TRIGGER
  before insert
  on USERS
  for each row
  BEGIN
  SELECT Users_ID_Seq.NEXTVAL
  INTO   :new.ID
  FROM   dual;
END;
/

