create trigger KORISNICIMIRZA_ID_TRIGGER
  before insert
  on KORISNICIMIRZA
  for each row
  BEGIN
  SELECT KorisniciMirza_ID_Seq.NEXTVAL
  INTO   :new.ID
  FROM   dual;
END;
/

