create trigger FAJLOVIDELILA_NAME_TRIGGER
  before insert
  on FAJLOVIDELILA
  for each row
  DECLARE
  broj INTEGER;
BEGIN
  SELECT COUNT(*) INTO broj
      FROM FajloviDelila fd
      WHERE fd.ID = :new.KorisnikID;
  IF ( broj > 0 ) THEN
    RAISE_APPLICATION_ERROR(-20343, 'Navedeni fajl vec postoji!');
  END IF;
END;
/

