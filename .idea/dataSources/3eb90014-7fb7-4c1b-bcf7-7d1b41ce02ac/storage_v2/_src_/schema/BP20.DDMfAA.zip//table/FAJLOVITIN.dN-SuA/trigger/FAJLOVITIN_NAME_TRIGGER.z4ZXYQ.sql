create trigger FAJLOVITIN_NAME_TRIGGER
  before insert
  on FAJLOVITIN
  for each row
  DECLARE
  broj INTEGER;
BEGIN
  SELECT COUNT(*) INTO broj
      FROM FajloviTin ft
      WHERE ft.ID = :new.KorisnikID;
  IF ( broj > 0 ) THEN
    RAISE_APPLICATION_ERROR(-20343, 'Navedeni fajl vec postoji!');
  END IF;
END;
/

