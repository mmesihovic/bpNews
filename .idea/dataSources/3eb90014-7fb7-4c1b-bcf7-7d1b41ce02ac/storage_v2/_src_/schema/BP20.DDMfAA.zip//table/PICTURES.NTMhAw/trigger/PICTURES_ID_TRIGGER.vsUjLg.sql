create trigger PICTURES_ID_TRIGGER
  before insert
  on PICTURES
  for each row
  BEGIN
  SELECT Pictures_ID_Seq.NEXTVAL
  INTO   :new.ID
  FROM   dual;
END;
/

