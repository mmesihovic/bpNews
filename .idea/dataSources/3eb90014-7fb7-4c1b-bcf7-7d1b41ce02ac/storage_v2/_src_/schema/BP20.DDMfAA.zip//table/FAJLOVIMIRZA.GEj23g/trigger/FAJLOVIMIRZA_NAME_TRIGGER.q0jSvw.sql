create trigger FAJLOVIMIRZA_NAME_TRIGGER
  before insert
  on FAJLOVIMIRZA
  for each row
  DECLARE
  broj INTEGER;
BEGIN
  SELECT COUNT(*) INTO broj
      FROM FajloviMirza fm
      WHERE fm.ID = :new.KorisnikID;
  IF ( broj > 0 ) THEN
    RAISE_APPLICATION_ERROR(-20343, 'Navedeni fajl vec postoji!');
  END IF;
END;
/

