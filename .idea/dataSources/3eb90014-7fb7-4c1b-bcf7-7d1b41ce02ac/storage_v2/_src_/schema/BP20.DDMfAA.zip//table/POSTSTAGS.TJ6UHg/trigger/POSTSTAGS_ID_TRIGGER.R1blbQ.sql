create trigger POSTSTAGS_ID_TRIGGER
  before insert
  on POSTSTAGS
  for each row
  BEGIN
  SELECT PostsTags_ID_Seq.NEXTVAL
  INTO   :new.ID
  FROM   dual;
END;
/

