create trigger FAJLOVIDELILA_ID_TRIGGER
  before insert
  on FAJLOVIDELILA
  for each row
  BEGIN
  SELECT FajloviDelila_ID_Seq.NEXTVAL
  INTO   :new.ID
  FROM   dual;
END;
/

