create trigger CATEGORIES_ID_TRIGGER
  before insert
  on CATEGORIES
  for each row
  BEGIN
  SELECT Categories_ID_Seq.NEXTVAL
  INTO   :new.ID
  FROM   dual;
END;
/

