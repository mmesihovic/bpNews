create trigger POSTSCATEGORIES_ID_TRIGGER
  before insert
  on POSTSCATEGORIES
  for each row
  BEGIN
  SELECT PostsCategories_ID_Seq.NEXTVAL
  INTO   :new.ID
  FROM   dual;
END;
/

