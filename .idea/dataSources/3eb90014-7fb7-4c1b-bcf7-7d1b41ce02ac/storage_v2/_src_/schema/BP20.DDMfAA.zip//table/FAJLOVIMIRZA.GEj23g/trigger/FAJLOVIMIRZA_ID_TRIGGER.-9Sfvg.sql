create trigger FAJLOVIMIRZA_ID_TRIGGER
  before insert
  on FAJLOVIMIRZA
  for each row
  BEGIN
  SELECT FajloviMirza_ID_Seq.NEXTVAL
  INTO   :new.ID
  FROM   dual;
END;
/

